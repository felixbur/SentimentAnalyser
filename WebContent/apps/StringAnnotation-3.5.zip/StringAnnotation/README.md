gateplugin-stringannotation
===========================

A plugin for the <a href="https://gate.ac.uk">GATE language technology</a> framework that provides PRs for string annotation.

This is an updated and modified version (not backwards compatible any more) of what can be found here: https://code.google.com/p/gateplugin-stringannotation/ 

For more information please consult the Wiki: https://github.com/johann-petrak/gateplugin-stringannotation/wiki

To download see: https://github.com/johann-petrak/gateplugin-stringannotation/releases

Feedback: please report bugs or feature request to the issue tracker: https://github.com/johann-petrak/gateplugin-stringannotation/issues
