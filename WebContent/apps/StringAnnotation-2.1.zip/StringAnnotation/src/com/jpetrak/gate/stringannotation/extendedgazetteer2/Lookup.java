package com.jpetrak.gate.stringannotation.extendedgazetteer2;



// TODO: make this just an interface or abstract class, with the actual
// implementation a subclass in one of the implementation packages!

/**
 */
public abstract class Lookup {
 
} // Lookup
