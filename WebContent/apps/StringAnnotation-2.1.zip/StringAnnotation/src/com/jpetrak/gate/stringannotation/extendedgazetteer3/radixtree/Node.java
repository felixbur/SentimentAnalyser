package com.jpetrak.gate.stringannotation.extendedgazetteer3.radixtree;

public class Node {
  public static int nrNodes = 0;
  public static int nrChars = 0;

}
