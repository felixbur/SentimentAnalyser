/**
 * 
 */
/**
 * @author Johann Petrak
 *
 */
package com.jpetrak.gate.stringannotation.extendedgazetteer2;