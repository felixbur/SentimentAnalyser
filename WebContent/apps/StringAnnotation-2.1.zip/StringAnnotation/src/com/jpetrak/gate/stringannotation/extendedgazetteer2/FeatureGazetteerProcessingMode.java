package com.jpetrak.gate.stringannotation.extendedgazetteer2;

public enum FeatureGazetteerProcessingMode {
    AddFeatures, 
    OverwriteFeatures, 
    RemoveAnnotation, 
    KeepAnnotation, 
    AddNewAnnotation 
}
